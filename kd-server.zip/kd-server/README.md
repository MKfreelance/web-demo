# Kaif & Delicious — Order Server

## Deploy on Railway (Free)

1. GitHub pe upload karo yeh folder
2. railway.app pe jao → New Project → Deploy from GitHub
3. Repo select karo
4. Environment Variables set karo (optional — default values already hain):
   - `TELEGRAM_TOKEN` = your bot token
   - `TELEGRAM_CHAT_ID` = your chat id
5. Deploy ho jaayega — URL milega (e.g. `https://kd-server.up.railway.app`)
6. Woh URL website frontend mein `SERVER_URL` variable mein daal do

## API Endpoints
- `GET /` — health check
- `POST /order` — new order (website calls this)
- `POST /confirm` — manually confirm order
- `GET /status` — see active reminders
