const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// ── CONFIG ──
const TELEGRAM_TOKEN = process.env.TELEGRAM_TOKEN || '8908965629:AAGioYpwvGc6gE21dDIesANCFWPlQ2xBkwg';
const TELEGRAM_CHAT_ID = process.env.TELEGRAM_CHAT_ID || '8258137553';
const REMINDER_INTERVAL_MS = 30000; // 30 seconds
const PORT = process.env.PORT || 3000;

// ── IN-MEMORY STORE ──
// { orderId: { order, intervalId, reminderCount, confirmed } }
const activeReminders = {};

// ── TELEGRAM HELPERS ──
async function sendTelegram(text) {
  try {
    await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: TELEGRAM_CHAT_ID,
        text,
        parse_mode: 'HTML',
        disable_notification: false
      })
    });
  } catch (e) {
    console.error('sendTelegram error:', e.message);
  }
}

async function sendTelegramVoice() {
  // Send a pre-generated beep tone (base64 encoded 2-sec alert MP3)
  // We use a public domain beep URL as fallback since we can't embed base64 here cleanly
  // Instead we send a short voice message via sendAudio with a tiny beep
  try {
    // Use sendMessage with a loud bell emoji as audio cue (simple & reliable)
    // For actual audio: upload MP3 via multipart — but needs file on disk
    const fs = require('fs');
    const path = require('path');
    const audioPath = path.join(__dirname, 'alert.mp3');

    if (fs.existsSync(audioPath)) {
      const FormData = require('form-data');
      const fd = new FormData();
      fd.append('chat_id', TELEGRAM_CHAT_ID);
      fd.append('voice', fs.createReadStream(audioPath), { filename: 'alert.mp3', contentType: 'audio/mpeg' });
      await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendVoice`, {
        method: 'POST',
        body: fd,
        headers: fd.getHeaders()
      });
    }
  } catch (e) {
    console.error('sendVoice error:', e.message);
  }
}

// ── TELEGRAM POLLING (getUpdates) for CONFIRM messages ──
let lastUpdateId = 0;
let pollingActive = false;

async function initUpdateOffset() {
  try {
    const r = await fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/getUpdates?limit=1&offset=-1`);
    const d = await r.json();
    if (d.result && d.result.length > 0) {
      lastUpdateId = d.result[d.result.length - 1].update_id + 1;
    }
    console.log(`📡 Telegram offset initialized: ${lastUpdateId}`);
  } catch (e) {
    console.error('initUpdateOffset error:', e.message);
  }
}

async function pollTelegram() {
  if (pollingActive) return;
  pollingActive = true;
  try {
    const r = await fetch(
      `https://api.telegram.org/bot${TELEGRAM_TOKEN}/getUpdates?offset=${lastUpdateId}&limit=20&timeout=25`,
      { timeout: 30000 }
    );
    const d = await r.json();
    if (!d.ok || !d.result) return;

    for (const upd of d.result) {
      lastUpdateId = upd.update_id + 1;
      const text = (upd.message?.text || '').trim().toUpperCase();

      // Detect: CONFIRM KD123456
      if (text.startsWith('CONFIRM ')) {
        const parts = text.split(/\s+/);
        // parts[1] is the order ID
        const orderId = parts[1];
        if (orderId && activeReminders[orderId]) {
          await handleConfirm(orderId);
        } else if (orderId) {
          // Maybe order ID with different casing
          const found = Object.keys(activeReminders).find(
            id => id.toUpperCase() === orderId
          );
          if (found) await handleConfirm(found);
        }
      }
    }
  } catch (e) {
    console.error('pollTelegram error:', e.message);
  } finally {
    pollingActive = false;
    // Keep polling continuously
    setTimeout(pollTelegram, 1000);
  }
}

async function handleConfirm(orderId) {
  const entry = activeReminders[orderId];
  if (!entry || entry.confirmed) return;

  entry.confirmed = true;
  clearInterval(entry.intervalId);
  delete activeReminders[orderId];

  console.log(`✅ Order ${orderId} confirmed via Telegram`);

  await sendTelegram(
`✅ <b>Order Confirmed — Reminder Band!</b>

🆔 #${orderId} — ${entry.order.customerName}
📞 ${entry.order.customerPhone}
💰 ₹${entry.order.total}

Reminder band ho gaye. Order accepted! 🎉`
  );
}

// ── START REMINDER for an order ──
function startReminder(order) {
  const { id: orderId, customerName, customerPhone, total } = order;

  if (activeReminders[orderId]) {
    console.log(`Reminder already running for ${orderId}`);
    return;
  }

  let count = 0;

  const intervalId = setInterval(async () => {
    const entry = activeReminders[orderId];
    if (!entry || entry.confirmed) {
      clearInterval(intervalId);
      return;
    }

    count++;
    console.log(`⏰ Sending reminder #${count} for order ${orderId}`);

    await sendTelegram(
`⏰ <b>REMINDER #${count} — Order Pending!</b>

🚨 Order <b>#${orderId}</b> abhi tak confirm nahi hua!

👤 <b>${customerName}</b>
📞 ${customerPhone}
💰 <b>₹${total}</b>

Confirm karne ke liye likho:
<b>CONFIRM ${orderId}</b>`
    );

    // Voice alert with every reminder
    await sendTelegramVoice();

  }, REMINDER_INTERVAL_MS);

  activeReminders[orderId] = { order, intervalId, reminderCount: 0, confirmed: false };
  console.log(`🔔 Reminder started for order ${orderId}`);
}

// ── API ROUTES ──

// Health check
app.get('/', (req, res) => {
  const pending = Object.keys(activeReminders).length;
  res.json({
    status: 'ok',
    service: 'Kaif & Delicious Order Server',
    pendingReminders: pending,
    uptime: Math.floor(process.uptime()) + 's'
  });
});

// POST /order — called from website when customer places order
app.post('/order', async (req, res) => {
  try {
    const order = req.body;

    // Validate required fields
    if (!order.id || !order.customerName || !order.total) {
      return res.status(400).json({ error: 'Missing required order fields' });
    }

    const timeStr = new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
    const itemsList = (order.items || [])
      .map(i => `  ${i.emoji || ''} ${i.name} × ${i.qty} — ₹${i.price}`)
      .join('\n');

    // Send initial order notification to Telegram
    await sendTelegram(
`🚨 <b>NEW ORDER — Kaif &amp; Delicious</b>

🆔 <b>Order ID:</b> ${order.id}
👤 <b>Name:</b> ${order.customerName}
📞 <b>Phone:</b> ${order.customerPhone}
📧 <b>Email:</b> ${order.customerEmail}
📍 <b>Address:</b> ${order.address}
⏰ <b>Time:</b> ${timeStr}

🛒 <b>Items:</b>
${itemsList}

💰 <b>Total: ₹${order.total}</b>
${order.notes ? '📝 <b>Notes:</b> ' + order.notes : ''}

✅ Confirm karne ke liye likho: <b>CONFIRM ${order.id}</b>
⏰ Har <b>30 seconds</b> mein reminder aata rahega jab tak confirm na ho.`
    );

    // Send voice alert
    await sendTelegramVoice();

    // Start 30-sec reminder loop
    startReminder(order);

    res.json({ success: true, orderId: order.id, message: 'Order received, reminders started' });

  } catch (e) {
    console.error('POST /order error:', e.message);
    res.status(500).json({ error: 'Server error' });
  }
});

// POST /confirm — manual confirm from admin panel (optional)
app.post('/confirm', async (req, res) => {
  const { orderId } = req.body;
  if (!orderId) return res.status(400).json({ error: 'orderId required' });

  if (activeReminders[orderId]) {
    await handleConfirm(orderId);
    res.json({ success: true, message: `Order ${orderId} confirmed, reminders stopped` });
  } else {
    res.json({ success: false, message: `No active reminder for ${orderId}` });
  }
});

// GET /status — check active reminders
app.get('/status', (req, res) => {
  const list = Object.entries(activeReminders).map(([id, entry]) => ({
    orderId: id,
    customerName: entry.order.customerName,
    total: entry.order.total,
    confirmed: entry.confirmed
  }));
  res.json({ activeReminders: list });
});

// ── START SERVER ──
app.listen(PORT, async () => {
  console.log(`🚀 KD Order Server running on port ${PORT}`);
  await initUpdateOffset();
  // Start Telegram polling loop
  setTimeout(pollTelegram, 2000);
  console.log('📡 Telegram polling started');
});
